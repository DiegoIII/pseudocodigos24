//Se declara una función, se definen los argumentos y la operación
//a retornar 
Funcion calcularAreaRombo <- calcularAreaRombo ( diagonalMayor, diagonalMenor )
    area <- (diagonalMayor * diagonalMenor) / 2 
    Retornar area 
Fin Funcion

Algoritmo calcularAreaRombo
    Escribir "Ingrese la longitud de la diagonal mayor del rombo:"
    Leer diagonalMayor

    Escribir "Ingrese la longitud de la diagonal menor del rombo:"
    Leer diagonalMenor

    //Vamos a llamar a nuestra función (invocar)
    area <- calcularAreaRombo(diagonalMayor, diagonalMenor) 
    Escribir "El área del rombo es: ", area 
FinAlgoritmo